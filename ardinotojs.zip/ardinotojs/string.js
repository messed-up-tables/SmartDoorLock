//T=32.84 P=998.08 A=127.05 H=59.42 AX=-571 AY=24 AZ=9579 GX=-35 GY=-1=-571 AY=24 AZ=9579 GX=-35 GY=-115 GZ=-220 MX=249  MY=-357 MZ=-9115

let text = "32.84 998.08 127.05"

const myArray = text.split(" ");
console.log(myArray)