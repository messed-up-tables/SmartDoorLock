let arval;
  let i = 0;

  for (i = 0; ; i++) {
    if (array[i] == "t") {
      arval[0] = array[i +1];
    }

    if (array[i] == "p") {
      arval[1] = array[i + 1];
    }
    if (array[i] == "h") {
      arval[2] = array[i + 1];
    }
    if (array[i] == "a") {
      arval[3] = array[i + 1];
    }
    if (array[i] == "ax") {
      arval[4] = array[i + 1];
    }
    if (array[i] == "ay") {
      arval[5] = array[i + 1];
    }
    if (array[i] == "az") {
      arval[6] = array[i + 1];
    }
    if (array[i] == "gx") {
      arval[7] = array[i + 1];
    }
    if (array[i] == "gy") {
      arval[8] = array[i + 1];
    }

    if (array[i] == "gz") {
      arval[9] = array[i + 1];
    }


    if (array[i] == "mx") {
      arval[10] = array[i + 1];
    }
    if (array[i] == "my") {
      arval[11] = array[i + 1];
    }
    if (array[i] == "mz") {
      arval[12] = array[i+1];
    }


  }

