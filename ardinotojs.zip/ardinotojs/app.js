var http = require('http');
const path = require('path');
var fs = require('fs');
const Server = require('socket.io');
var index = fs.readFileSync('index.html');
var express = require('express');
var app = express();
app.use(express.static('public'));

const { SerialPort } = require('serialport')
const { ReadlineParser } = require('@serialport/parser-readline')





var port = new SerialPort({
  path: "COM4",
  baudRate: 9600,
  dataBits: 8,
  parity: 'none',
  stopBits: 1,
  flowControl: false,
});

const parser = port.pipe(new ReadlineParser({ delimiter: '\r\n' }))

function sendToSerial(datax) {
  console.log("sending to serial: " + datax);
  port.write(datax);
}

port.pipe(parser);

var app = http.createServer(function (req, res) {
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(index);
}).listen(8080);

var appImg = http.createServer(function (req, res) {
 
    let jpgPath= path.join(__dirname, "public", req.url);
    let jpgReadStream= fs.createReadStream(jpgPath);
    res.statusCode= 200;
    res.setHeader( "Content-Type", "image/jpg");
    jpgReadStream.pipe(res);
}).listen(3000);

var io = require('socket.io')(app);

io.on('connection', function (socket) {

  console.log('Node is listening to port');
  //data from html

  socket.on('serialevent',(msg) => {
    console.log('message: ' + msg);
    port.write(msg)//sending data to arduno
  })

});



let array;
let arval=[];
let ggppss;
parser.on('data', function (data) {

  //console.log('Received data from port: ' + data);
  array = data.split(" ")
  //console.log(array)

  //function
  
  let i = 0;

  if(array.length>20){
  for (i = 0; i < array.length ; i++) {
    if (array[i] == "t") {
      arval[0] =parseFloat( array[i + 1]);
    }

    if (array[i] == "p") {
      arval[1] =0.1*parseFloat( array[i + 1]);
    }
    if (array[i] == "h") {
      arval[2] = parseFloat( array[i + 1]);
    }
    if (array[i] == "a") {
      arval[3] = 0.45*parseFloat( array[i + 1]);
    }
    if (array[i] == "ax") {
      arval[4] = 2.9*0.013*parseFloat( array[i + 1]);
    }
    if (array[i] == "ay") {
      arval[5] = 2.9*0.149*parseFloat( array[i + 1]);
    }
    if (array[i] == "az") {
      arval[6] = 2.9*0.001225*parseFloat( array[i + 1]);
    }
    if (array[i] == "gx") {
      arval[7] = parseFloat( array[i + 1]);
    }
    if (array[i] == "gy") {
      arval[8] = parseFloat( array[i + 1]);
    }

    if (array[i] == "gz") {
      arval[9] = parseFloat( array[i + 1]);
    }
    if (array[i] == "mx") {
      arval[10] = parseFloat( array[i + 1]);
    }
    if (array[i] == "my") {
      arval[11] = parseFloat( array[i + 1]);
    }
    if (array[i] == "mz") {
      arval[12] = parseFloat( array[i + 1]);
    }

    //randomgenerate

    
    // if (array[i] == "latitud") {
    //   arval[13] = parseFloat( array[i + 1]);
    // }

    // if (array[i] == "longitude") {
    //   arval[14] = parseFloat( array[i + 1]);
    // }


    arval[15] = "23.7809N__90.378781E";

 



  }}

  // if(array.length<20)
  // {

  
  //   {
  //     arval[0]= Math.round((Math.random() * 2 + 29)* 100) / 100;
    
  //     arval[1]=  Math.round((Math.random() * 30 + 990)* 100) / 100;
  //     arval[3]=  Math.round((Math.random() * 10 + 122)* 100) / 100;
  //     arval[2]=  Math.round((Math.random() * 5 + 70)* 100) / 100;
  //     arval[4]=  Math.round((Math.random() * 10 + 820)* 100) / 100;
  //     arval[5]=  Math.round((Math.random() * 10 - 270)* 100) / 100;
  //     arval[6]=  Math.round((Math.random() * 25 + 320)* 100) / 100;
  //     arval[7]=  Math.round((Math.random() * 20 - 120)* 100) / 100;
  //     arval[8]=  Math.round((Math.random() * 25 + 27)* 100) / 100;
  //     arval[9]=  Math.round((Math.random() * 5 -55)* 100) / 100;
  //     arval[10]=  Math.round((Math.random() * 30 + 300)* 100) / 100;
  //     arval[11]=  Math.round((Math.random() * 40 -300)* 100) / 100;
  //     arval[12]=  Math.round((Math.random() * 50-800)* 100) / 100;



  //   }
  // }
  //console.log(arval)


  io.emit('data', arval); 

});

// app.listen(3000);

//chgport

// function intconverted(stringArray) {
//   var numberArray = [];

// length = stringArray.length;


// for (var i = 0; i < length; i++)
//     if (isNaN(stringArray[i])) {
        
//     }
//     else{
//         numberArray.push(parseInt(stringArray[i]));
//     }

//     return 
// }